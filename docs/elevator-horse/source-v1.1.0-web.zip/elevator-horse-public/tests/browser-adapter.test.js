'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const createBridge = require('../web/adapter');
const Application = require('../src/application');
const settle = () => new Promise(resolve => setImmediate(resolve));
function target(extra = {}) {
  const handlers = new Map();
  return Object.assign(extra, {
    addEventListener(type, fn) { if (!handlers.has(type)) handlers.set(type, new Set()); handlers.get(type).add(fn); },
    removeEventListener(type, fn) { handlers.get(type)?.delete(fn); },
    fire(type, event = {}) { for (const fn of [...(handlers.get(type) || [])]) fn(Object.assign({ cancelable: true, preventDefault() {} }, event)); }
  });
}
function setup(options = {}) {
  let time = 1000, frameId = 0;
  const gradient = { addColorStop() {} };
  const context = new Proxy({}, { get: (o, k) => k === 'measureText' ? text => ({ width: text.length * 7 }) : k === 'createLinearGradient' ? () => gradient : o[k] || (() => {}), set: (o, k, value) => { o[k] = value; return true; } });
  const captures = [], canvas = target({ getContext: () => context, getBoundingClientRect: () => ({ left: 120, top: 0, width: 390, height: 844 }), setPointerCapture(id) { captures.push(id); }, focus() {} });
  const sharePanel = { hidden: true }, shareText = { value: '', focus() {}, select() { this.selected = true; } }, close = target();
  const elements = { game: canvas, 'safe-insets': {}, 'share-panel': sharePanel, 'share-text': shareText, 'close-share': close };
  const doc = target({ hidden: false, getElementById: id => elements[id] });
  const values = new Map(), copied = [], shared = [], notices = [], media = [];
  const storage = { getItem: key => values.get(key), setItem: (key, value) => values.set(key, value) };
  class FakeAudio {
    constructor() { this.events = {}; this.currentTime = 0; this.volume = 1; this.muted = false; this.paused = true; media.push(this); }
    addEventListener(type, fn) { this.events[type] = fn; }
    play() { this.paused = false; return options.audioFailure ? Promise.reject(new Error('autoplay-denied')) : Promise.resolve(); }
    pause() { this.paused = true; }
  }
  const nav = options.noClipboard ? {} : { clipboard: { writeText: async text => { if (options.clipboardFailure) throw new Error('clipboard-denied'); copied.push(text); } } };
  if (options.share) nav.share = async data => { shared.push(data); if (options.shareError) throw options.shareError; };
  const win = target({ document: doc, innerWidth: 1000, innerHeight: 844, devicePixelRatio: 2, location: { href: 'https://example.test/games/elevator-horse/?score=20#old' }, navigator: nav, Audio: FakeAudio, getComputedStyle: () => ({ paddingTop: '24px', paddingBottom: '16px' }) });
  Object.defineProperty(win, 'localStorage', { get() { if (options.blockStorage) throw new Error('storage-denied'); return storage; } });
  let app;
  const bridge = createBridge(win, canvas, text => { notices.push(text); if (app) app.toast(text); });
  app = new Application(bridge.api, { now: () => time, requestFrame: () => ++frameId, cancelFrame() {} }).boot();
  const point = (id, action) => {
    const hit = app.renderer.hits.find(h => h.id === action); assert.ok(hit, 'missing ' + action);
    const l = app.renderer.layout;
    return { pointerId: id, pointerType: 'touch', button: 0, clientX: 120 + l.x + (hit.x + hit.w / 2) * l.scale, clientY: l.y + (hit.y + hit.h / 2) * l.scale };
  };
  return { win, doc, canvas, app, bridge, point, captures, copied, shared, notices, values, media, sharePanel, shareText, close,
    advance(ms) { time += ms; app.tick(); } };
}
test('real pointer coordinates start and hold the centered game without a second finger releasing it', async () => {
  const f = setup(), start = f.point(1, 'start');
  f.canvas.fire('pointerdown', start); f.canvas.fire('pointerup', start);
  assert.equal(f.app.engine.mode, 'playing');
  const hold = f.point(7, 'hold'), other = f.point(8, 'hold');
  f.canvas.fire('pointerdown', hold); assert.equal(f.app.engine.holding, true);
  f.canvas.fire('pointerdown', other); f.canvas.fire('pointerup', other); f.canvas.fire('lostpointercapture', other);
  assert.equal(f.app.engine.holding, true);
  f.canvas.fire('pointerup', hold); assert.equal(f.app.engine.holding, false);
  assert.deepEqual(f.captures, [1, 7, 8]); await settle();
});
test('sliding outside the continuous hold zone or losing the captured finger releases disguise', () => {
  const f = setup(); f.app.act('start');
  const hold = f.point(1, 'hold'); f.canvas.fire('pointerdown', hold);
  f.canvas.fire('pointermove', { ...hold, clientY: 0 }); assert.equal(f.app.engine.holding, false);
  f.canvas.fire('pointerdown', hold); f.canvas.fire('lostpointercapture', hold); assert.equal(f.app.engine.holding, false);
  f.canvas.fire('pointerdown', hold); f.canvas.fire('pointercancel', hold); assert.equal(f.app.touchId, null);
});
test('background events freeze time and clear fingers; returning stays paused until explicit resume', () => {
  const f = setup(); f.app.act('start'); f.advance(100);
  f.canvas.fire('pointerdown', f.point(3, 'hold'));
  const elapsed = f.app.engine.elapsed; f.win.fire('blur'); f.doc.hidden = true; f.doc.fire('visibilitychange'); f.advance(120000);
  assert.equal(f.app.engine.elapsed, elapsed); assert.equal(f.app.engine.holding, false); assert.equal(f.app.hidden, true);
  f.doc.hidden = false; f.doc.fire('visibilitychange'); assert.equal(f.app.hidden, true);
  f.win.fire('focus'); assert.equal(f.app.hidden, false); assert.equal(f.app.engine.mode, 'paused');
  f.app.act('resume'); f.advance(16); assert.ok(f.app.engine.elapsed - elapsed < .02);
});
test('browser resizing respects safe insets and pauses an active hold', () => {
  const f = setup(); f.app.act('start'); f.canvas.fire('pointerdown', f.point(2, 'hold')); f.win.fire('resize');
  assert.equal(f.app.engine.mode, 'paused'); assert.equal(f.app.engine.holding, false);
  const info = f.bridge.api.getWindowInfo(); assert.equal(info.windowWidth, 390); assert.deepEqual(info.safeArea, { top: 24, bottom: 828 });
});
test('blocked or corrupt local storage cannot break a game and retains in-page records', () => {
  const f = setup({ blockStorage: true }); f.bridge.api.setStorageSync('record', { best: 100 });
  assert.deepEqual(f.bridge.api.getStorageSync('record'), { best: 100 }); assert.equal(f.notices.length, 1);
  f.bridge.api.setStorageSync('record', { best: 200 }); assert.equal(f.notices.length, 1);
  const good = setup(); good.values.set('broken', '{invalid'); assert.equal(good.bridge.api.getStorageSync('broken'), undefined);
});
test('sharing supplies a real stable URL and score to the native browser panel', async () => {
  const f = setup({ share: true }); f.bridge.api.shareAppMessage({ title: '挑战120分', query: 'score=120' }); await settle();
  assert.equal(f.shared[0].url, 'https://example.test/games/elevator-horse/?score=120'); assert.equal(f.shared[0].text, '挑战120分'); assert.equal(f.copied.length, 0);
});
test('unavailable or failed sharing copies the link; cancellation does not pretend to share or copy', async () => {
  const f = setup(); f.bridge.api.shareAppMessage({ title: '来玩', query: 'score=10' }); await settle(); assert.match(f.copied[0], /https:\/\/example.test\/games\/elevator-horse\/\?score=10/);
  const denied = setup({ share: true, shareError: new Error('denied') }); denied.bridge.api.shareAppMessage({ title: '来玩', query: '' }); await settle(); assert.equal(denied.copied.length, 1);
  const canceled = setup({ share: true, shareError: Object.assign(new Error('cancel'), { name: 'AbortError' }) }); canceled.bridge.api.shareAppMessage({ title: '来玩' }); await settle(); assert.equal(canceled.copied.length, 0); assert.equal(canceled.notices.length, 0);
});
test('copy rejection reports failure and exposes selectable text instead of a false success', async () => {
  const f = setup({ clipboardFailure: true }); let ok = 0, fail = 0;
  f.bridge.api.setClipboardData({ data: '我的战绩 80', success() { ok++; }, fail() { fail++; } }); await settle();
  assert.equal(ok, 0); assert.equal(fail, 1); assert.equal(f.sharePanel.hidden, false); assert.equal(f.shareText.selected, true); assert.match(f.shareText.value, /我的战绩 80\nhttps:/);
  f.close.fire('click'); assert.equal(f.sharePanel.hidden, true);
});
test('audio autoplay failure is caught and gameplay remains functional', async () => {
  const f = setup({ audioFailure: true }), start = f.point(1, 'start');
  f.canvas.fire('pointerdown', start); f.canvas.fire('pointerup', start);
  f.app.audio.play('warning'); await settle(); assert.equal(f.app.engine.mode, 'playing');
  f.bridge.dispose(); assert.ok(f.media.every(media => media.paused));
});
test('the actual browser entry preserves the native animation-frame receiver for scheduling and cancellation', () => {
  const f = setup(); let scheduled = 0, canceled = 0, liveApp;
  f.win.requestAnimationFrame = function (callback) { assert.equal(this, f.win); assert.equal(typeof callback, 'function'); scheduled++; return 91; };
  f.win.cancelAnimationFrame = function (id) { assert.equal(this, f.win); assert.equal(id, 91); canceled++; };
  class CapturedApplication extends Application { constructor(api, runtime) { super(api, runtime); liveApp = this; } }
  const code = require('node:fs').readFileSync(require('node:path').resolve(__dirname, '../web/entry.js'), 'utf8');
  require('node:vm').runInNewContext(code, { window: f.win, document: f.doc, Date, require(id) {
    if (id === './application') return CapturedApplication;
    if (id === './browser-adapter') return createBridge;
    throw new Error('Unexpected browser module ' + id);
  } });
  assert.equal(scheduled, 1); assert.ok(liveApp); liveApp.act('start'); f.win.fire('blur');
  assert.equal(canceled, 1); assert.equal(liveApp.engine.mode, 'paused');
});
test('the production build embeds only local modules and keeps four sound files', () => {
  const path = require('node:path'), fs = require('node:fs');
  require('node:child_process').execFileSync(process.execPath, ['build.cjs'], { cwd: path.resolve(__dirname, '..') });
  const dist = path.resolve(__dirname, '../dist'), html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8'), code = fs.readFileSync(path.join(dist, 'game.js'), 'utf8');
  assert.match(html, /viewport-fit=cover/); assert.match(html, /game\.js\?v=[a-f0-9]{12}/); assert.doesNotMatch(html, /<iframe|https:\/\//);
  new (require('node:vm').Script)(code); assert.doesNotMatch(code, /window\.app\s*=|window\.advance\s*=/);
  assert.equal(fs.readdirSync(path.join(dist, 'assets/audio')).filter(n => n.endsWith('.wav')).length, 4);
});
