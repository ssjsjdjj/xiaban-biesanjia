'use strict';

// Browser implementation of the small wx surface used by the original game.
// No game state or test hooks are exposed on window.
module.exports = function createBrowserBridge(win, canvas, notify = function () {}) {
  const doc = win.document, listeners = [], callbacks = {}, memory = new Map(), players = [];
  let hidden = false, focused = true, warmed = false, warnedStorage = false;
  const listen = (target, type, fn, options) => {
    target.addEventListener(type, fn, options); listeners.push(() => target.removeEventListener(type, fn, options));
  };
  const emit = (name, data) => { if (callbacks[name]) callbacks[name](data); };
  function foreground() {
    const next = !!doc.hidden || !focused;
    if (next === hidden) return;
    hidden = next; emit(next ? 'hide' : 'show');
  }
  const localTouch = event => {
    const box = canvas.getBoundingClientRect();
    return { identifier: event.pointerId, clientX: event.clientX - box.left, clientY: event.clientY - box.top };
  };
  function unlockAudio() {
    if (warmed) return; warmed = true;
    for (const player of players) player.unlock();
  }
  for (const [native, kind] of [['pointerdown', 'start'], ['pointermove', 'move'], ['pointerup', 'end'], ['pointercancel', 'cancel'], ['lostpointercapture', 'cancel']]) {
    listen(canvas, native, event => {
      if (native === 'pointerdown' && event.pointerType === 'mouse' && event.button !== 0) return;
      if (event.cancelable) event.preventDefault();
      if (native === 'pointerdown') {
        unlockAudio();
        try { canvas.setPointerCapture(event.pointerId); } catch (_) {}
      }
      emit(kind, { changedTouches: [localTouch(event)] });
    }, { passive: false });
  }
  listen(canvas, 'contextmenu', event => event.preventDefault());
  listen(win, 'blur', () => { focused = false; foreground(); });
  listen(win, 'focus', () => { focused = true; foreground(); });
  listen(doc, 'visibilitychange', foreground);
  listen(win, 'pagehide', () => { focused = false; foreground(); });
  listen(win, 'pageshow', () => { focused = true; foreground(); });
  listen(win, 'resize', () => emit('resize'));
  listen(win, 'orientationchange', () => emit('resize'));

  const currentUrl = query => {
    const url = new URL(win.location.href); url.hash = '';
    if (query) for (const [key, value] of new URLSearchParams(query)) url.searchParams.set(key, value);
    return url.href;
  };
  async function copyText(text) {
    if (!win.navigator.clipboard || typeof win.navigator.clipboard.writeText !== 'function') throw new Error('clipboard-unavailable');
    await win.navigator.clipboard.writeText(text);
  }
  function offerManualCopy(text) {
    const panel = doc.getElementById('share-panel'), field = doc.getElementById('share-text');
    if (panel && field) {
      field.value = text; panel.hidden = false; field.focus(); field.select();
    }
    notify('自动复制不可用，请长按选中文本复制链接。');
  }
  const api = {
    createCanvas: () => canvas,
    getWindowInfo() {
      const box = canvas.getBoundingClientRect();
      let top = 0, bottom = 0;
      try {
        const probe = doc.getElementById('safe-insets'), style = win.getComputedStyle(probe);
        top = parseFloat(style.paddingTop) || 0; bottom = parseFloat(style.paddingBottom) || 0;
      } catch (_) {}
      const width = Math.max(1, box.width || win.innerWidth), height = Math.max(1, box.height || win.innerHeight);
      return { windowWidth: width, windowHeight: height, pixelRatio: Math.min(win.devicePixelRatio || 1, 3), safeArea: { top, bottom: height - bottom } };
    },
    getStorageSync(key) {
      try { const value = win.localStorage.getItem(key); return value ? JSON.parse(value) : memory.get(key); }
      catch (_) { return memory.get(key); }
    },
    setStorageSync(key, value) {
      memory.set(key, value);
      try { win.localStorage.setItem(key, JSON.stringify(value)); }
      catch (_) { if (!warnedStorage) { warnedStorage = true; notify('浏览器未允许保存记录，本次游玩仍可继续。'); } }
    },
    onTouchStart: fn => { callbacks.start = fn; }, onTouchMove: fn => { callbacks.move = fn; },
    onTouchEnd: fn => { callbacks.end = fn; }, onTouchCancel: fn => { callbacks.cancel = fn; },
    onHide: fn => { callbacks.hide = fn; }, onShow: fn => { callbacks.show = fn; }, onWindowResize: fn => { callbacks.resize = fn; },
    getLaunchOptionsSync: () => ({ query: Object.fromEntries(new URL(win.location.href).searchParams) }),
    setClipboardData(options) {
      const text = options.data + '\n' + currentUrl();
      copyText(text).then(() => { if (options.success) options.success(); }, error => {
        if (options.fail) options.fail(error); offerManualCopy(text);
      });
    },
    shareAppMessage(options) {
      const data = { title: '电梯里禁止变成马', text: options.title, url: currentUrl(options.query) };
      const fallback = () => copyText(data.text + '\n' + data.url).then(() => notify('挑战链接已复制，发给好友即可。'), () => offerManualCopy(data.text + '\n' + data.url));
      if (typeof win.navigator.share !== 'function') { fallback(); return; }
      try {
        Promise.resolve(win.navigator.share(data)).catch(error => { if (!error || error.name !== 'AbortError') fallback(); });
      } catch (_) { fallback(); }
    },
    createInnerAudioContext() {
      const media = new win.Audio(); media.preload = 'auto';
      let onError = function () {}, requested = false;
      media.addEventListener('error', event => onError(event));
      const player = {
        set src(value) { media.src = value; }, get src() { return media.src; },
        set volume(value) { media.volume = value; }, get volume() { return media.volume; },
        onError(fn) { onError = fn; },
        play() {
          requested = true;
          try { const promise = media.play(); if (promise && promise.catch) promise.catch(onError); } catch (error) { onError(error); }
        },
        stop() { requested = false; try { media.pause(); media.currentTime = 0; } catch (_) {} },
        unlock() {
          media.muted = true;
          try {
            Promise.resolve(media.play()).then(() => { if (!requested) player.stop(); media.muted = false; }, () => { media.muted = false; });
          } catch (_) { media.muted = false; }
        }
      };
      players.push(player); return player;
    }
  };
  const close = doc.getElementById('close-share');
  if (close) listen(close, 'click', () => { doc.getElementById('share-panel').hidden = true; canvas.focus(); });
  return { api, dispose() { for (const off of listeners) off(); for (const player of players) player.stop(); } };
};
