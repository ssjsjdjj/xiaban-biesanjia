(function () {
  'use strict';
  const canvas = document.getElementById('game');
  let application;
  const bridge = require('./browser-adapter')(window, canvas, message => { if (application) application.toast(message, 3200); });
  application = new (require('./application'))(bridge.api, {
    now: () => Date.now(),
    requestFrame: callback => window.requestAnimationFrame(callback),
    cancelFrame: id => window.cancelAnimationFrame(id)
  }).boot();
})();
